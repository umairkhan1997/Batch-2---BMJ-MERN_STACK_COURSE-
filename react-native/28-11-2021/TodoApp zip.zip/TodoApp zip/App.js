import React, { useState } from "react";
import { View, Text, Button, TextInput } from "react-native";

const App = () => {
  const [todos, setTodos] = useState([]);
  const [value, setValue] = useState('');
  const onAddTodo = () => {
    setTodos([...todos,value])
  }

  const onInputChange = (value) => {
    setValue(value);
  }
  const onKeyPress = (e) => {
    console.log('key', e.nativeEvent.key)
  }
  console.log(todos)
  return (
    <View>
      <Text numberOfLines={2} ellipsizeMode="tail">Hello from Expo CLI! Hello from Expo CLI!Hello from Expo CLI!Hello from Expo CLI!Hello from Expo CLI!Hello from Expo CLI!Hello from Expo CLI!Hello from Expo CLI!Hello from Expo CLI!Hello from Expo CLI!Hello from Expo CLI!Hello from Expo CLI!Hello from Expo CLI!</Text>
      <Text>I am learing React native.</Text>
      <TextInput 
        placeholder="Enter new Todo Item"
        value={value}
        onChangeText={onInputChange}
        // autoCapitalize="words" 
        // autoComplete="email" 
        // editable={true}
        // returnKeyLabel="Submit"
        // numberOfLines={3}
        // returnKeyType="search"
        // onKeyPress={onKeyPress}
        // secureTextEntry={true}
        style={{width: 400, height: 50}}
        />
      {/* {todos.map((item) => <Text>{item}</Text>)}
      <Button disabled={todos.length === 10} onPress={onAddTodo} title="Add Todo" color="#ff0000"/> */}
      <Text dataDetectorType ="all">+923233239933</Text>
    </View>
  );
};

export default App;
