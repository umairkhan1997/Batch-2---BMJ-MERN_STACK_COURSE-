const mongoose = require('mongoose');

const Schema = mongoose.Schema;

// Object, Array, Number, Boolean, String;

const ProductSchema = new Schema({
    name: String,
    price: Number,
    category: String,
    currency: String,
    discount: Number,
    discountedPrice: Number
});

ProductSchema.methods.getPrice = function () {
    let newPrice = this.price;
    if(this.discount) {
        newPrice -= this.discount;
    }

    return newPrice;
}


const ProductModel = mongoose.model('Product', ProductSchema);

module.exports = ProductModel;