const express = require('express');
const db = require('./db')
const app = express();
const PORT = 3000;
const Product = require('./models/products/model');

// tables - collections
// rows - document
// column - field
// const product = {
//     name: "products 2",
//     category: "xyz",
//     price: "123",
//     currency: "pkr",
//     discount: 50
// };

// const newProduct = new Product(product);
// newProduct.discountedPrice = newProduct.getPrice();
// newProduct.save();
// console.log('connected', newProduct.getPrice())


// const users = [
//     {
//         id:'0983490 8934083490',
//         fullName: "Bill Gates",
//         position: "Founder Microsoft",
//         salary: ""
//     },
//     {
//         id:'0983490 8934083490',
//         fullName: "Bill Gates",
//         position: "Founder Microsoft",
//     },
//     // {
//     //     "name": "user 1",
//     //     age: 1,
//     //     verified: true,
//     //     "skills": [],
//     //     "location": {
//     //         lat: 13.32353,
//     //         lng: 84.98340934
//     //     }
//     // }
// ]

const bodyParser = express.json();
app.use(bodyParser);

app.get('/', (req, res) => {
    res.statusCode = 200;
    res.send('<h1>Hello world</h1>')
})


app.get('/products', async (req, res) => {
 const allProducts = await Product.find();
//  const allProducts = await Product.find({ name: "123", discount: 50 });
 return res.json(allProducts);
})

app.post('/products', async(req, res) => {
    const product = req.body;
    const newProduct = new Product(
        
        
    );
    await newProduct.save();

    return res.send({
        message: "success",
        data: newProduct,
        error: null
    })

})

app.get('/product/:id', async (req, res)=> {
    const productId = req.params.id; 
    const productDetail = await Product.findById(productId);

    return res.send({
        message: "success",
        data: productDetail,
        error: null
    })
})


app.delete('/product/:id', async (req, res) => {
    const productId = req.params.id;
    const productDetail = await Product.findOneAndDelete({ name: 'Iphone 7'});
    // const productDetail = await Product.findByIdAndDelete(productId);

    return res.send({
        message: "success",
        data: productDetail,
        error: null
    })
})

app.patch('/product/:id', async (req, res) => {
    const productId = req.params.id;
    const newProduct = req.body;
    try {
        // const isProductExist = await Product.findById(productId);
        const productDetail = await Product.findOneAndReplace(
            { _id: productId },
            newProduct,
            {new : true }
            );
        // const productDetail = await Product.findByIdAndDelete(productId);
    
        return res.send({
            message: "success",
            data: productDetail,
            error: null
        })
        
    } catch (error) {
        return res.send({
            message: "fail",
            data: null,
            error: 'Internal Server Error'
        })
    }
    console.log(isProductExist)
})

app.listen(PORT, (err) => {
    if(err) {
        console.log(err);
        return;
    }

    console.log(`Server is running on http://localhost:${PORT}`)
})
