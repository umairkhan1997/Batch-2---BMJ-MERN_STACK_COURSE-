import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './life-cycle-functional-component';

ReactDOM.render(
    <App />,
  document.getElementById('root')
);