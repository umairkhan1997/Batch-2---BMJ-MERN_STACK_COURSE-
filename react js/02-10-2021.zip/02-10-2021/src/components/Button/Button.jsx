const Button = ({ addTodo }) => {
  return <button onClick={addTodo}>Add</button>;
};

export default Button;
