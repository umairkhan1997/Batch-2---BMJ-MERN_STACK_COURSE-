const Input = ({onInputChange}) => {
  return <input placeholder="Add Todo" onChange={onInputChange} />;
};

export default Input;