import React from "react";
import { connect } from "react-redux";

const Todo = (props) => {
    const onAddItem = () => {
        props.dispatch({ 
            type: "ADD_TODO",
            payload: "item " + Math.floor(Math.random() * 100000)
         })
    }
    console.log(props)
    return (
        <div>
            <button onClick={onAddItem}>Add Item</button>
        </div>
    )
}

const mapStateToProps = (state) => {
    return {
        todos: state.todos
    }
}
const connectTodo = connect(mapStateToProps);


export default connectTodo(Todo);