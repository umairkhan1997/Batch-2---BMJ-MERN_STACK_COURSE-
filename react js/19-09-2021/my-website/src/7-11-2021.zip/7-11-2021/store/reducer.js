const INITIAL_STATE = {
    counter: 0,
    todos: []
}

function reducer (state = INITIAL_STATE, action) {
    const newState = { ...state };

    switch(action.type) {
        case "INCREMENT":
            newState.counter = newState.counter + 1;
            break;
        case "DECREMENT":
            newState.counter = newState.counter - 1;
            break;
        case "ADD_TODO":
            newState.todos = [...newState.todos, action.newItem]
    }

    return newState;
}

export default reducer;