function Title() {
    return <h1>My Website</h1>
}

export default Title