import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import App from './life-cycle-functional-component';
import App from "./27-2-2022/App"
ReactDOM.render(
    <App />,
  document.getElementById('root')
);