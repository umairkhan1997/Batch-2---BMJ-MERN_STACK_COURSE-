import logo from './logo.svg';
import img1 from "./assets/images/pic1.jpg"
import './App.css';
import Title from "./components/Title";
import Image from './components/Image';
function App() {
  return (
    <div className="App">
      <Image src={logo} className="App-logo"></Image>
      <Image src={img1}></Image>
      <Title></Title>
    </div>
  )
  
}

export default App;
